# Soybean_Images_MachineLearning
Image Dataset of Soybean plants for Machine Learning 
This is for the Unite for Humanity hackathon team project for automating "disease" detection for hydroponic plants in remote/developing countries and networked communities. 

The sources for diceased plant content information for demo are from the following university extension program amongst others: 

1. Soy Downy Mildew 
http://www.extension.umn.edu/agriculture/crop-diseases/soybean/downymildew.html

2. Soybean Rust Disease
http://www.extension.umn.edu/agriculture/crop-diseases/soybean/soybeanrust.html

Image sources collected across the interweb to be posted shortly with healthy and diseased plants as a "ready-made" collection for neural network/image processing did not already exist to our knowledge. 
